import React from 'react';
import Nav from '../navbarThree/Navbar3';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Progressbar from './Progressbar';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Card18 from './Card18';
import Box from '@material-ui/core/Box';
import Chart from './Chart';
import BoxesResponses from './BoxesResponses'
import { Button, Paper } from '@material-ui/core';
import socialnet from './socialnet.svg'
import Footer from '../Footer/Footer';

const useStyles = makeStyles((theme) => ({

  pagePadding:{
    paddingLeft:  "3rem",
    paddingRight:  "3rem"
  
  },
  
  }));

export default function DashboardLanding() {
  const classes = useStyles();

  return (
<div>

<Nav/>


<Grid container direction="row" className={classes.pagePadding} >


<Grid item md={8} >
<p className={classes.pagePadding} 
style={{float:"left", fontWeight:"600", fontSize:"30px"}}>Good morning, Raymond</p>


  </Grid>
  </Grid>
  <Grid container direction="row" className={classes.pagePadding} >


<Grid item md={8} >
<p className={classes.pagePadding}  style={{float:"left", fontSize:"18px", fontWeight:"600", marginTop:"-0.5rem"}}>ONGOING SESSIONS</p>

  </Grid>
  </Grid>


<Grid container direction="row"  className={classes.pagePadding} 
>


<Grid item md={8} >
<Card18/>

<Box display="flex" flexDirection="row" style={{marginTop:"1rem"}} >
        <Box>
        <Chart/>
            </Box>
            <Box style={{marginLeft:"1rem"}}>
            <BoxesResponses/>
            </Box>
            </Box>


<Paper  style={{borderRadius:"10px"}}>

<Box display="flex"  style={{marginTop:"1rem", backgroundImage: "linear-gradient(to right,#30758f,#5aa5ac)"}} >
      
        <Box  >
        <Box p={1}>
<img src={socialnet} alt="socialnet" />
</Box>

        </Box>
        <Box  flexGrow={1} >
<p style={{color:"#ffff"}}>
Engage with fellow coaches and build connections <br/>
Start networking, look out for opportunities
</p>
        </Box>
        <Box style={{width:"25%", marginTop:"1rem"}} >
    <Button style={{color:"black", backgroundColor:"#ffff"}}>
      JOIN NOW
    </Button>
        </Box>
      </Box>

</Paper>
</Grid>


<Grid item md={4} >



hjhj


</Grid>


</Grid>

<br/>
<br/>
<br/>
<Footer/>

</div>
  );
}
